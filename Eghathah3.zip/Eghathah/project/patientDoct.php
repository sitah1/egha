<?php
session_start();
?>
<!DOCTYPE html>
<html lang="en">

<head>

  <meta charset="UTF-8">
<meta http-equiv="X-UA-Compatible" content= "IE=edge" />
  <title> إغاثة</title>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css" integrity="sha512-z3gLpd7yknf1YoNbCzqRKc4qyor8gaKU1qmn+CShxbuBusANI9QpRohGBreCFkKxLhei6S9CQXFEbbKuqLg0DA==" crossorigin="anonymous" referrerpolicy="no-referrer" />

  <link href="welcom.css" rel="stylesheet" type="text/css"/>
   <link href="foteerNheader.css" rel="stylesheet" type="text/css"/>
   
<body>
 <header>
  <div class="navbar">
  <img src="C:\Users\Its_e\OneDrive\المستندات\e.jpg" class="logoe">
  <ul class="links">
  <li><a href="logout.php"> تسجيل خروج </a></li>
  <li><a href="#contact"> تواصل  </a></li>
  </ul>
  <div class="toggle_btn" id="toggle_btn">
   <i class="fa-solid fa-bars"></i>
   </div>
   </div>
  
 </header>
 
 <section style="margin-top:300px;margin-left:700px">
 <h3>ادخل اسم الدكتور</h3>
 <form action="" method="post">

 <?php
$conn = new mysqli('localhost','root','','eghatha');
if($conn->connect_error){
    echo "$conn->connect_error";
    die("Connection Failed : ". $conn->connect_error);
} 

$sql = "SELECT id,Doctor_Name FROM doctors";
$result = $conn->query($sql);
if ($result->num_rows > 0) {
    echo '<select name="doc" id="doc" style="font-size:24pt;width:300px;">';
    while ($row = $result->fetch_assoc()) {
        $name = $row['Doctor_Name'];
        $id = $row['id'];
        echo '<option value="'.$id.'">' . $name . '</option>';
    }
    echo '</select>';
} else {
    echo "No data found.";
}

?>

</br>
</br>

     <input type="submit" name="submit" value="save" style="font-size:24pt;width:300px;">

 </form>
 </section>
</body>
</html>

<?php
if(isset($_POST['submit'])){
    $option = $_POST['doc'];
    $Patient_ID = $_SESSION['patientID'];
    $stmt = $conn->prepare("insert into patient_doctor(	patientID, DoctorID) values(?, ?)");
		$stmt->bind_param("ii", $Patient_ID, $option);
		$execval= $stmt->execute();
        header("location:patientHome.php");

}
?>