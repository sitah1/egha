<!DOCTYPE html>
<html>
<head>
  <link rel="icon" type="image/x-icon" href="C:\Users\Its_e\OneDrive\المستندات\e.jpg">
<meta charset="UTF-8">
<meta name="description" content=" إغاثه هُنا دائمًا لمُساعدتك ">
<meta name="keywords" content="مساعده, صحه , إغاثه ">
<meta http-equiv="X-UA-Compatible" content= "IE=edge" />
<meta name="viewport" content-"width=device-width , initial-scale=1.0" />
<title>تسجيل</title>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css" integrity="sha512-z3gLpd7yknf1YoNbCzqRKc4qyor8gaKU1qmn+CShxbuBusANI9QpRohGBreCFkKxLhei6S9CQXFEbbKuqLg0DA==" crossorigin="anonymous" referrerpolicy="no-referrer" />
<link rel="stylesheet" href="log.css">
<link rel="stylesheet" href="welcome.css">
<link rel="stylesheet" href="foteerNheader.css">



    <header>
  <div class="navbar">
  <img src="C:\Users\Its_e\OneDrive\المستندات\e.jpg" class="logoe">
  <ul class="links">
  <li><a href="#">عن إغاثه </a></li>
  <li><a href="login.php"> تسجيل دخول </a></li>
  <li><a href="signup.php"> تسجيل جديد </a></li>
  <li><a href="#contact"> تواصل  </a></li>
  </ul>
  <div class="toggle_btn" id="toggle_btn">
   <i class="fa-solid fa-bars"></i>
   </div>
   </div>
   
   
   <div class="dr_menu" >
   <li><a href="#About"> عن إغاثة </a></li>
   <li><a href="login.php"> تسجيل دخول </a></li>
   <li><a href="login.php"> تسجيل جديد </a></li>
   <li><a href="#contact"> تواصل  </a></li>
   </div>
  
   </header>

    <script src="all.js"></script>
    </head>

<body>
<div class="container1">
 <div class="formbox">
  <h1 id="title"> تسجيل جديد </h1>
  <p> بقيامك بالتسجيل هُنا سوف تقوم بالتسجيل كمريض وستستفيد من خدمات منصة إغاثه التستتيح لك ان تسجل بياناتك المرضيه وكيف الاعتناء بحالتك وقت وقوع شي خطير لا سمح الله من قبل متطوعين من العامه من خلال باركود يكون بحوزتك </p>
  <form action="" method="post" id="frm">
  <div class="inputgroup">
    <div class ="inputfild" id="namef" >
     <i class="fa-solid fa-user"></i>
     <input type="text" name="User_ID" placeholder="رقم الهوية">
   </div>
 </div>

<div class ="inputfild" >
<i class="fa-solid fa-envelope"></i>
<input type="email"  name="User_Email" placeholder="البريد الالكروني ">
</div>

<div class ="inputfild" >
<i class="fa-solid fa-lock"></i>
<input type="password" name="User_Password" placeholder="كلمة المرور">
</div>

<div class ="inputfild" >
  <i class="fa-solid fa-lock"></i>
  <input type="password" name="confirmPassword" placeholder="كلمة كرر المرور">
  </div>


  <div class ="inputfild" >

مريض <input type="radio" name="type" value="patient" checked>
دكتور <input type="radio" name="type" value="Doctor">
</div>

</br> </br>

<div class="btnfild"> 
<button  type="submit" name="submit"  id="signbtn" >  تسجيل جديد </button>
</div>
<input  type="checkbox" id="ت" name="ت" /> تذكرني
</div>
</div>
</form>
<footer>
        <div class="copyright">
            &copy; 2023 إغاثة - المملكة العربية السعودية 
  
		<div class="links">
		<a href="#" class="fa-brands fa-twitter"></a> |
            <a href="#">شروط الاستخدام</a> |
            <a href="#">اتصل بنا</a>
        </div>
		</div>
    </footer>
	
</body>
</html>

<?php
if(isset($_POST['submit'])){
	$User_ID = $_POST['User_ID'];
	$User_Email = $_POST['User_Email'];
	$User_Password = $_POST['User_Password'];
  $type = $_POST['type'];
	// Database connection
	$conn = new mysqli('localhost','root','','eghatha');
	if($conn->connect_error){
		echo "$conn->connect_error";
		die("Connection Failed : ". $conn->connect_error);
	} else {
		$stmt = $conn->prepare("insert into `usert`(`Usert_ID`, `User_Email`, `User_Password`, `type`) VALUES (?, ?, ?,?)");
		$stmt->bind_param("isss", $User_ID, $User_Email, $User_Password,$type);
		$execval= $stmt->execute();
	    echo $execval;
		echo "<script> alert('Registration successfully...') </script>";
    header("location:login.php");
		$stmt->close();
		$conn->close();
	}}
?>