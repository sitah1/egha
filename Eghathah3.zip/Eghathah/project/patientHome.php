<?php
session_start();
?>
<!DOCTYPE html>
<html lang="ar">
<head>
<link rel="icon" type="image/x-icon" href="C:\Users\Its_e\OneDrive\المستندات\e.jpg">
<meta charset="UTF-8">
<meta name="description" content=" إغاثه هُنا دائمًا لمُساعدتك ">
<meta name="keywords" content="مساعده, صحه , إغاثه ">
<meta http-equiv="X-UA-Compatible" content= "IE=edge" />
<meta name="viewport" content-"width=device-width , initial-scale=1.0" />
<link rel="stylesheet" type="text/css" href="all3.css">
<link rel="stylesheet" type="text/css" href="foteerNheader.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css" integrity="sha512-z3gLpd7yknf1YoNbCzqRKc4qyor8gaKU1qmn+CShxbuBusANI9QpRohGBreCFkKxLhei6S9CQXFEbbKuqLg0DA==" crossorigin="anonymous" referrerpolicy="no-referrer" />
<meta charset="UTF-8">
<title>بيانات المريض</title>
</head>
<body>
<header>
  <div class="navbar">
  <img src="C:\Users\Its_e\OneDrive\المستندات\e.jpg" class="logoe">
  <ul class="links">
  <li><a href="logout.php"> تسجيل خروج </a></li>
  <li><a href="#contact"> تواصل  </a></li>
  </ul>
  <div class="toggle_btn" id="toggle_btn">
   <i class="fa-solid fa-bars"></i>
   </div>
   </div>
  
 </header>

<?php
$conn = new mysqli('localhost','root','','eghatha');
if($conn->connect_error){
    echo "$conn->connect_error";
    die("Connection Failed : ". $conn->connect_error);
} 
$Patient_ID = $_SESSION['patientID'];
$sql = "SELECT * FROM patient where User_ID = '$Patient_ID'";
$result = $conn->query($sql);
if ($result->num_rows > 0) {
    echo "<style>
            table {
                width: 100%;
                border-collapse: collapse;
                
            }
            th, td {
                padding: 8px;
                text-align: left;
                border: 1px solid #ddd;
            }
            th {
                background-color: #f2f2f2;
            }
          </style>";
    echo "<table>";
    echo "<tr><th>Patient_ID</th><th>Patient_Name</th><th>Patient_Age</th><th>Patient_Weight</th>
    <th>Patient_Height</th><th>Patient_BloodG</th><th>Patient_Medicine</th><th>Patient_FirstAid</th>
    <th>Patient_MedicalHistory</th> <th>Relatives_EmergencyNum</th></tr>";
    while ($row = $result->fetch_assoc()) {
        echo "<tr>";
        echo "<td>" . $row["Patient_ID"] . "</td>";
        echo "<td>" . $row["Patient_Name"] . "</td>";
        echo "<td>" . $row["Patient_Age"] . "</td>";
        echo "<td>" . $row["Patient_Weight"] . "</td>";
        echo "<td>" . $row["Patient_Height"] . "</td>";
        echo "<td>" . $row["Patient_BloodG"] . "</td>";
        echo "<td>" . $row["Patient_Medicine"] . "</td>";
        echo "<td>" . $row["Patient_FirstAid"] . "</td>";
        echo "<td>" . $row["Patient_MedicalHistory"] . "</td>";
        echo "<td>" . $row["Relatives_EmergencyNum"] . "</td>";
        ?>
        <td>  <a style="color:black;" href="updatePatientByP.php?ID=<?php echo $row['Patient_ID'];?>">Update</a></td> 
          <?php echo "</tr>";
    }
    echo "</table>";
}else{
?>



<div class="container">
<br/><br/> 
 
        <h2>ادخل بيانات المريض</h2>
		<form class="right" id="userForm" action="" method="post">
	
	    <label for="identity"> : الهويه </label>
        <input type="text" id="identity" name="Patient_ID" required><br><br>
		
        <label for="name"> : الاسم</label>
        <input type="text" id="name" name="Patient_Name" required><br><br>

        <label for="age"> : العمر</label>
        <input type="number" id="age" name="Patient_Age" required><br><br>

        <label for="height"> : الطول</label>
        <input type="number" id="height" name="Patient_Height" required><br><br>
		
		<label for="weight"> : الوزن</label>
        <input type="number" id="weight" name="Patient_Weight" required><br><br>

        <label for="weight"> : فصيلة الدم </label>
        <input type="number" id="weight" name="Patient_BloodG" required><br><br>

        <label for="illness"> : الامراض</label>
        <input type="text" id="illness" name="Patient_MedicalHistory"><br><br>

        
        <label for="medication"> : الادوية</label>
        <input type="text" id="medication" name="Patient_Medicine"><br><br>
		
		<!--see it later"Name"-->
		<!-- see it later "name"-->
		<label for="relativeEmergncyNumber"> : رقم طوارئ</label>
        <input type="tel" id="relativeEmergncyNumber" name="Relatives_EmergencyNum" required><br><br>
		
        <label for="first_aid">: مالذي قد يفعله المتطوع في حال حدث لك اغماء او حاله حرجه ؟</label>
        <textarea id="first_aid" name="Patient_FirstAid" rows="4"></textarea><br><br>

        
       
        <input class="send" name="submit" type="submit" value="Submit">
		
    </form>
	</div>
<?php }?>
		    <!-- <footer style="position: fixed;left: 0;bottom: 0;width: 100%;">
        <div class="copyright">
            &copy; 2023 إغاثة - المملكة العربية السعودية 
  
		<div class="links">
		<a href="https://twitter.com/eghathahhelp" class="fa-brands fa-twitter"></a> |
            <a href="#">شروط الاستخدام</a> |
            <a href=mailto:“EghathahHelp@hotmail.com”> اتصل بنا</a>
        </div>
		</div>
    </footer> -->
</body>
</html>
<?php
if(isset($_POST['submit'])){
	$Patient_ID = $_POST['Patient_ID'];
	$Patient_Name = $_POST['Patient_Name'];
	$Patient_Age = $_POST['Patient_Age'];
	$Patient_Height = $_POST['Patient_Height'];
	$Patient_Weight = $_POST['Patient_Weight'];
	$Patient_FirstAid = $_POST['Patient_FirstAid'];
	$Patient_MedicalHistory = $_POST['Patient_MedicalHistory'];
	$Patient_Medicine = $_POST['Patient_Medicine'];
	$Relatives_EmergencyNum = $_POST['Relatives_EmergencyNum'];
	$Patient_BloodG = $_POST['Patient_BloodG'];
    $userID = $_SESSION['patientID'];

	


	// Database connection
	$conn = new mysqli('localhost','root','','eghatha');
	if($conn->connect_error){
		echo "$conn->connect_error";
		die("Connection Failed : ". $conn->connect_error);
	} else {
		$stmt = $conn->prepare("insert into patient(Patient_ID,User_ID,Patient_Name, Patient_Age, Patient_Weight, Patient_Height, Patient_BloodG, Patient_Medicine,  Patient_FirstAid, Patient_MedicalHistory, Relatives_EmergencyNum) values(?, ?, ?, ?, ?, ?, ?, ?, ?, ? , ? )");
		$stmt->bind_param("sssssssssss", $Patient_ID,$userID, $Patient_Name, $Patient_Age, $Patient_Weight, $Patient_Height, $Patient_BloodG, $Patient_Medicine,  $Patient_FirstAid, $Patient_MedicalHistory, $Relatives_EmergencyNum);
		$execval= $stmt->execute();
	    echo $execval;
        header("location:patientDoct.php");
		$stmt->close();
		$conn->close();
	}
}
?>