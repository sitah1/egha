<?php
session_start();
$conn = new mysqli('localhost','root','','eghatha');
if($conn->connect_error){
    echo "$conn->connect_error";
    die("Connection Failed : ". $conn->connect_error);
} 
$Patient_ID = $_GET['ID'];
$sql = "SELECT * FROM patient where Patient_ID = '$Patient_ID'";
$result = $conn->query($sql);
if($result->num_rows > 0){
    $row = $result->fetch_assoc();
    $Patient_ID = $row['Patient_ID'];
	$Patient_Name = $row['Patient_Name'];
	$Patient_Age = $row['Patient_Age'];
	$Patient_Height = $row['Patient_Height'];
	$Patient_Weight = $row['Patient_Weight'];
	$Patient_FirstAid = $row['Patient_FirstAid'];
	$Patient_MedicalHistory = $row['Patient_MedicalHistory'];
	$Patient_Medicine = $row['Patient_Medicine'];
	$Relatives_EmergencyNum = $row['Relatives_EmergencyNum'];
	$Patient_BloodG = $row['Patient_BloodG'];
}
?>
<!DOCTYPE html>
<html lang="ar">
<head>
<link rel="icon" type="image/x-icon" href="C:\Users\Its_e\OneDrive\المستندات\e.jpg">
<meta charset="UTF-8">
<meta name="description" content=" إغاثه هُنا دائمًا لمُساعدتك ">
<meta name="keywords" content="مساعده, صحه , إغاثه ">
<meta http-equiv="X-UA-Compatible" content= "IE=edge" />
<meta name="viewport" content-"width=device-width , initial-scale=1.0" />
<link rel="stylesheet" type="text/css" href="all3.css">
<link rel="stylesheet" type="text/css" href="foteerNheader.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css" integrity="sha512-z3gLpd7yknf1YoNbCzqRKc4qyor8gaKU1qmn+CShxbuBusANI9QpRohGBreCFkKxLhei6S9CQXFEbbKuqLg0DA==" crossorigin="anonymous" referrerpolicy="no-referrer" />
<meta charset="UTF-8">
<title>بيانات المريض</title>
</head>
<body>
<header>
  <div class="navbar">
  <img src="C:\Users\Its_e\OneDrive\المستندات\e.jpg" class="logoe">
  <ul class="links">
  <li><a href="logout.php"> تسجيل خروج </a></li>
  <li><a href="#contact"> تواصل  </a></li>
  </ul>
  <div class="toggle_btn" id="toggle_btn">
   <i class="fa-solid fa-bars"></i>
   </div>
   </div>
  
 </header>



<div class="container">
<br/><br/> 
 
        <h2>تعديل بيانات المريض</h2>
		<form class="right" id="userForm" action="" method="post">
	
	  
        <label for="illness"> : الامراض</label>
        <input type="text" id="illness" value="<?php echo $Patient_MedicalHistory;?>" name="Patient_MedicalHistory"><br><br>

        
        <label for="medication"> : الادوية</label>
        <input type="text" id="medication" value="<?php echo $Patient_Medicine;?>" name="Patient_Medicine"><br><br>
		
        <label for="first_aid">: مالذي قد يفعله المتطوع في حال حدث لك اغماء او حاله حرجه ؟</label>
        <textarea id="first_aid" name="Patient_FirstAid" rows="4"><?php echo $Patient_FirstAid;?></textarea><br><br>

        
       
        <input class="send" name="submit" type="submit" value="Save">
		
    </form>
	</div>
		    <footer style="position: fixed;left: 0;bottom: 0;width: 100%;">
        <div class="copyright">
            &copy; 2023 إغاثة - المملكة العربية السعودية 
  
		<div class="links">
		<a href="https://twitter.com/eghathahhelp" class="fa-brands fa-twitter"></a> |
            <a href="#">شروط الاستخدام</a> |
            <a href=mailto:“EghathahHelp@hotmail.com”> اتصل بنا</a>
        </div>
		</div>
    </footer>
</body>
</html>
<?php
if(isset($_POST['submit'])){
	$Patient_FirstAid = $_POST['Patient_FirstAid'];
	$Patient_MedicalHistory = $_POST['Patient_MedicalHistory'];
	$Patient_Medicine = $_POST['Patient_Medicine'];


	


	// Database connection
	$conn = new mysqli('localhost','root','','eghatha');
	if($conn->connect_error){
		echo "$conn->connect_error";
		die("Connection Failed : ". $conn->connect_error);
	} else {
		$stmt = $conn->prepare("update patient set  Patient_Medicine=?,  Patient_FirstAid=?, Patient_MedicalHistory=? where patient_ID = ?");

        $stmt->bind_param("ssss", $Patient_Medicine,  $Patient_FirstAid, $Patient_MedicalHistory,$Patient_ID);
		$execval= $stmt->execute();
	    echo $execval;
        header("location:doctorHome.php");
		$stmt->close();
		$conn->close();
	}
}
?>