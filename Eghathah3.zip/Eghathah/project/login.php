<?php
session_start(); 
if(isset($_POST['submit'])){
  $email = $_POST['User_Email'];
  $pass = $_POST['User_Password'];
  $type = $_POST['type'];
  $conn = new mysqli('localhost','root','','eghatha');
if($conn->connect_error){
    echo "$conn->connect_error";
    die("Connection Failed : ". $conn->connect_error);
} 
if($type == "patient"){
$sql = "SELECT usert_id FROM usert where User_Email = '$email' and User_Password = '$pass'";
$result = $conn->query($sql);
if ($result->num_rows > 0) {
  $row = $result->fetch_assoc();
  $_SESSION['patientID'] = $row['usert_id'];
  header("location:patientHome.php");
  }
  else
echo "<script> alert('Username or password is wrong ...!!!') </script>";
}
  else {
    $sql = "SELECT * FROM Doctors where username = '$email' and password = '$pass'";
$result = $conn->query($sql);
if ($result->num_rows > 0) {
  $row = $result->fetch_assoc();
      $_SESSION['doctorID'] = $row['id'];
      header("location:doctorHome.php");
  }
  else
echo "<script> alert('Username or password is wrong ...!!!') </script>";
}
}
?>
<!DOCTYPE html>
<html>
<head>
  <link rel="icon" type="image/x-icon" href="C:\Users\Its_e\OneDrive\المستندات\e.jpg">
<meta charset="UTF-8">
<meta name="description" content=" إغاثه هُنا دائمًا لمُساعدتك ">
<meta name="keywords" content="مساعده, صحه , إغاثه ">
<meta http-equiv="X-UA-Compatible" content= "IE=edge" />
<meta name="viewport" content-"width=device-width , initial-scale=1.0" />
<title>تسجيل</title>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css" integrity="sha512-z3gLpd7yknf1YoNbCzqRKc4qyor8gaKU1qmn+CShxbuBusANI9QpRohGBreCFkKxLhei6S9CQXFEbbKuqLg0DA==" crossorigin="anonymous" referrerpolicy="no-referrer" />
<link rel="stylesheet" href="log.css">
<link rel="stylesheet" href="welcome.css">
<link rel="stylesheet" href="foteerNheader.css">
    <header>
  <div class="navbar">
  <img src="C:\Users\Its_e\OneDrive\المستندات\e.jpg" class="logoe">
  <ul class="links">
  <li><a href="#">عن إغاثه </a></li>
  <li><a href="login.php"> تسجيل دخول </a></li>
  <li><a href="signup.php"> تسجيل جديد </a></li>
  <li><a href="#contact"> تواصل  </a></li>
  </ul>
  <div class="toggle_btn" id="toggle_btn">
   <i class="fa-solid fa-bars"></i>
   </div>
   </div>
   
   
   <div class="dr_menu" >
   <li><a href="#About"> عن إغاثة </a></li>
   <li><a href="login.php"> تسجيل دخkول </a></li>
   <li><a href="signup.php"> تسجيل جديد </a></li>
   <li><a href="#contact"> تواصل  </a></li>
   </div>
  
   </header>

    <script src="all.js"></script>
    </head>

<body>
<div class="container1">
 <div class="formbox">
  <h1 id="title"  > تسجيل الدخول </h1>
  <p> بقيامك بالتسجيل هُنا سوف تقوم بالتسجيل كمريض وستستفيد من خدمات منصة إغاثه التستتيح لك ان تسجل بياناتك المرضيه وكيف الاعتناء بحالتك وقت وقوع شي خطير لا سمح الله من قبل متطوعين من العامه من خلال باركود يكون بحوزتك </p>
  <form action="" method="post" id="frm">
  

<div class ="inputfild" >
<i class="fa-solid fa-envelope"></i>
<input type="email"  name="User_Email" placeholder="البريد الالكروني ">
</div>

<div class ="inputfild" >
<i class="fa-solid fa-lock"></i>
<input type="password" name="User_Password" placeholder="كلمة المرور">
</div>

<div class ="inputfild" >

مريض <input type="radio" name="type" value="patient" checked>
دكتور <input type="radio" name="type" value="Doctor">
</div>


</br> </br>

<div class="btnfild"> 
<button name="submit" type="submit"  id="signbtn" > تسجيل دخول </button>
</div>
<input  type="checkbox" id="ت" name="ت" /> تذكرني
</div>
</div>
</form>
<footer>
        <div class="copyright">
            &copy; 2023 إغاثة - المملكة العربية السعودية 
  
		<div class="links">
		<a href="#" class="fa-brands fa-twitter"></a> |
            <a href="#">شروط الاستخدام</a> |
            <a href="#">اتصل بنا</a>
        </div>
		</div>
    </footer>
</body>
</html>
