<?php
session_start();
?>
<!DOCTYPE html>
<html lang="ar">
<head>
<link rel="icon" type="image/x-icon" href="C:\Users\Its_e\OneDrive\المستندات\e.jpg">
<meta charset="UTF-8">
<meta name="description" content=" إغاثه هُنا دائمًا لمُساعدتك ">
<meta name="keywords" content="مساعده, صحه , إغاثه ">
<meta http-equiv="X-UA-Compatible" content= "IE=edge" />
<meta name="viewport" content-"width=device-width , initial-scale=1.0" />
<link rel="stylesheet" type="text/css" href="all3.css">
<link rel="stylesheet" type="text/css" href="foteerNheader.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css" integrity="sha512-z3gLpd7yknf1YoNbCzqRKc4qyor8gaKU1qmn+CShxbuBusANI9QpRohGBreCFkKxLhei6S9CQXFEbbKuqLg0DA==" crossorigin="anonymous" referrerpolicy="no-referrer" />
<meta charset="UTF-8">
<title>بيانات المريض</title>
</head>
<body>
<header>
  <div class="navbar">
  <img src="C:\Users\Its_e\OneDrive\المستندات\e.jpg" class="logoe">
  <ul class="links">
  <li><a href="logout.php"> تسجيل خروج </a></li>
  <li><a href="#contact"> تواصل  </a></li>
  </ul>
  <div class="toggle_btn" id="toggle_btn">
   <i class="fa-solid fa-bars"></i>
   </div>
   </div>
  
 </header>

<?php
$conn = new mysqli('localhost','root','','eghatha');
if($conn->connect_error){
    echo "$conn->connect_error";
    die("Connection Failed : ". $conn->connect_error);
} 
$doctorID = $_SESSION['doctorID'];
$sql = "SELECT * FROM patient inner join patient_doctor on patient.User_ID = patient_doctor.patientID where patient_doctor.doctorID = '$doctorID'";
$result = $conn->query($sql);
if ($result->num_rows > 0) {
    echo "<style>
            table {
                width: 100%;
                border-collapse: collapse;
                
            }
            th, td {
                padding: 8px;
                text-align: left;
                border: 1px solid #ddd;
            }
            th {
                background-color: #f2f2f2;
            }
          </style>";
    echo "<table>";
    echo "<tr><th>Patient_ID</th><th>Patient_Name</th><th>Patient_Age</th><th>Patient_Weight</th>
    <th>Patient_Height</th><th>Patient_BloodG</th><th>Patient_Medicine</th><th>Patient_FirstAid</th>
    <th>Patient_MedicalHistory</th> <th>Relatives_EmergencyNum</th><th>Operation</th></tr>";
    while ($row = $result->fetch_assoc()) {
        echo "<tr>";
        echo "<td>" . $row["Patient_ID"] . "</td>";
        echo "<td>" . $row["Patient_Name"] . "</td>";
        echo "<td>" . $row["Patient_Age"] . "</td>";
        echo "<td>" . $row["Patient_Weight"] . "</td>";
        echo "<td>" . $row["Patient_Height"] . "</td>";
        echo "<td>" . $row["Patient_BloodG"] . "</td>";
        echo "<td>" . $row["Patient_Medicine"] . "</td>";
        echo "<td>" . $row["Patient_FirstAid"] . "</td>";
        echo "<td>" . $row["Patient_MedicalHistory"] . "</td>";
        echo "<td>" . $row["Relatives_EmergencyNum"] . "</td>";
        ?>
     <td>  <a style="color:black;" href="updatePatient.php?ID=<?php echo $row['Patient_ID'];?>">Update</a></td> 
       <?php echo "</tr>";
    }
    echo "</table>";
}
?>

		    <footer style="position: fixed;left: 0;bottom: 0;width: 100%;">
        <div class="copyright">
            &copy; 2023 إغاثة - المملكة العربية السعودية 
  
		<div class="links">
		<a href="https://twitter.com/eghathahhelp" class="fa-brands fa-twitter"></a> |
            <a href="#">شروط الاستخدام</a> |
            <a href=mailto:“EghathahHelp@hotmail.com”> اتصل بنا</a>
        </div>
		</div>
    </footer>
</body>
</html>