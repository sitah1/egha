<!DOCTYPE html>
<html lang="en">

<head>

  <meta charset="UTF-8">
<meta http-equiv="X-UA-Compatible" content= "IE=edge" />
  <title> إغاثة</title>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css" integrity="sha512-z3gLpd7yknf1YoNbCzqRKc4qyor8gaKU1qmn+CShxbuBusANI9QpRohGBreCFkKxLhei6S9CQXFEbbKuqLg0DA==" crossorigin="anonymous" referrerpolicy="no-referrer" />

  <link href="welcom.css" rel="stylesheet" type="text/css"/>
   <link href="foteerNheader.css" rel="stylesheet" type="text/css"/>
   
<body>
 <header>
  <div class="navbar">
  <img src="C:\Users\Its_e\OneDrive\المستندات\e.jpg" class="logoe">
  <ul class="links">
  <li><a href="#">عن إغاثه </a></li>
  <li><a href="login.php"> تسجيل دخول </a></li>
  <li><a href="signup.php"> تسجيل جديد </a></li>
  <li><a href="#contact"> تواصل  </a></li>
  </ul>
  <div class="toggle_btn" id="toggle_btn">
   <i class="fa-solid fa-bars"></i>
   </div>
   </div>
   
   
   <div class="dr_menu" >
   <li><a href="#About"> عن إغاثة </a></li>
   <li><a href="about"> تسجيل دخول </a></li>
   <li><a href="services"> تسجيل جديد </a></li>
   <li><a href="#contact"> تواصل  </a></li>
   </div>
  
 </header>
 
 
 <main>
 
 <section id="hero">
 <h1> مرحبًا بك في موقع إغاثه </h1>
 </br> </br>
 <p class="font"> منصة اغاثة الالكترونية، هي منصه تُقدم مساعدة لمن يعانون من مُضاعفات الامراض المزمنه كالاغماء, والصرع بمساعده من الأشخاص من العامة بحيث يتوفر في منصة إغاثة معلومات المريض والارشادات اللازمه عند حدوث حاله حرجه , و مكالمات للطوارئ </p>
 </main>
 </section>
 
 <main>
 <section id="contact">
 <h1> تواصل معنا </h1>
 <p>او على حسابنا على تويتر  Eghatha@gmail.com  للتواصل الرجاء الارسال للبريد التالي  </p> 
 </section>
 </main>

    <script>
        const toggle_btn= document.querySelector('.toggle_btn')
        const togglebtnicon = document.querySelector('.toggle_btn i')
        const dropdm = document.querySelector('.dr_menu')
    
        toggle_btn.onclick = function() {
            dropdm.classList.toggle('open')
            const isOpen = dropdm.classList.contains('open')
    
            togglebtnicon.classList = isOpen
            ? "fa-solid fa-xmark"
            : "fa-solid fa-bars"
        
    }
    </script>

  <footer>
        <div class="copyright">
            &copy; 2023 إغاثة - المملكة العربية السعودية 
  
		<div class="links">
		<a href="#" class="fa-brands fa-twitter"></a> |
            <a href="#">شروط الاستخدام</a> |
            <a href="#">اتصل بنا</a>
        </div>
		</div>
    </footer>
 

</body>
</html>