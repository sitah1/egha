<!DOCTYPE html>
<html lang="ar">
<head>
<link rel="icon" type="image/x-icon" href="C:\Users\Its_e\OneDrive\المستندات\e.jpg">
<meta charset="UTF-8">
<meta name="description" content=" إغاثه هُنا دائمًا لمُساعدتك ">
<meta name="keywords" content="مساعده, صحه , إغاثه ">
<meta http-equiv="X-UA-Compatible" content= "IE=edge" />
<meta name="viewport" content-"width=device-width , initial-scale=1.0" />
<link rel="stylesheet" type="text/css" href="all3.css">
<link rel="stylesheet" type="text/css" href="foteerNheader.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css" integrity="sha512-z3gLpd7yknf1YoNbCzqRKc4qyor8gaKU1qmn+CShxbuBusANI9QpRohGBreCFkKxLhei6S9CQXFEbbKuqLg0DA==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <meta charset="UTF-8">
    <title>عرض بيانات المريض</title>
</head>
<style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f2f2f2;
            margin: 0;
            padding: 20px;
        }

        .patient-data {
            background-color: #fff;
            border: 1px solid #ccc;
            padding: 20px;
            margin-bottom: 20px;
        }

        h2 {
            color: #333;
        }

        .field-label {
            font-weight: bold;
        }

        .field-value {
            margin-bottom: 10px;
        }
    </style>
<body>
<header>
  <div class="navbar">
  <img src="C:\Users\Its_e\OneDrive\المستندات\e.jpg" class="logoe">
  <ul class="links">
  <li><a href="welcom.html">عن إغاثه </a></li>
  <li><a href="about"> تسجيل دخول </a></li>
  <li><a href="log.html"> تسجيل جديد </a></li>
  <li><a href="welcom.html#contact"> تواصل  </a></li>
  </ul>
  <div class="toggle_btn" id="toggle_btn">
   <i class="fa-solid fa-bars"></i>
   </div>
   </div>
   
   
   <div class="dr_menu" >
   <li><a href="#About"> عن إغاثة </a></li>
   <li><a href="about"> تسجيل دخول </a></li>
   <li><a href="services"> تسجيل جديد </a></li>
   <li><a href="#contact"> تواصل  </a></li>
   </div>
  
 </header>
    <?php
    require_once('dbh.php');
    // Retrieve the patient_id from the query parameter
    $patientID = $_GET['patient_id'];
    
    
    // Prepare the query
    $stmt = $conn->prepare("SELECT * FROM patient WHERE Patient_ID = ?");
    $stmt->bind_param("i", $patientID);
    
    // Execute the query
    $stmt->execute();
    
    // Get the result
    $result = $stmt->get_result();
    if ($result->num_rows > 0) {
        // Display the patient data
        while ($row = $result->fetch_assoc()) {
            echo '<div class="patient-data">';
            echo '<h2>Patient Information</h2>';
            echo '<div class="field">';
            echo '<span class="field-label">Patient ID:</span>';
            echo '<span class="field-value">' . $row['Patient_ID'] . '</span>';
            echo '</div>';
            echo '<div class="field">';
            echo '<span class="field-label">Patient Name:</span>';
            echo '<span class="field-value">' . $row['Patient_Name'] . '</span>';
            echo '</div>';
            echo '<div class="field">';
            echo '<span class="field-label">Patient Age:</span>';
            echo '<span class="field-value">' . $row['Patient_Age'] . '</span>';
            echo '</div>';
            echo '<div class="field">';
            echo '<span class="field-label">Patient Height:</span>';
            echo '<span class="field-value">' . $row['Patient_Height'] . '</span>';
            echo '</div>';
            echo '<div class="field">';
            echo '<span class="field-label">Patient Weight:</span>';
            echo '<span class="field-value">' . $row['Patient_Weight'] . '</span>';
            echo '</div>';
            echo '<div class="field">';
            echo '<span class="field-label">Patient Blood Group:</span>';
            echo '<span class="field-value">' . $row['Patient_BloodG'] . '</span>';
            echo '</div>';
            echo '<div class="field">';
            echo '<span class="field-label">Patient Medical History:</span>';
            echo '<span class="field-value">' . $row['Patient_MedicalHistory'] . '</span>';
            echo '</div>';
            echo '<div class="field">';
            echo '<span class="field-label">Patient Medicine:</span>';
            echo '<span class="field-value">' . $row['Patient_Medicine'] . '</span>';
            echo '</div>';
            echo '<div class="field">';
            echo '<span class="field-label">Relatives Emergency Number:</span>';
            echo '<span class="field-value">' . $row['Relatives_EmergencyNum'] . '</span>';
            echo '</div>';
            echo '<div class="field">';
            echo '<span class="field-label">Patient First Aid:</span>';
            echo '<span class="field-value">' . $row['Patient_FirstAid'] . '</span>';
            echo '</div>';
            echo '</div>';
        }
    } else {
        echo "No patient found with the given ID.";
    }
    
    // Close the database connection
    $stmt->close();
    $conn->close();
    ?>

<footer>
        <div class="copyright">
            &copy; 2023 إغاثة - المملكة العربية السعودية 
  
		<div class="links">
		<a href="https://twitter.com/eghathahhelp" class="fa-brands fa-twitter"></a> |
            <a href="#">شروط الاستخدام</a> |
            <a href=mailto:“EghathahHelp@hotmail.com”> اتصل بنا</a>
        </div>
		</div>
    </footer>

</body>
</html>