
        const toggle_btn= document.querySelector('.toggle_btn')
        const togglebtnicon = document.querySelector('.toggle_btn i')
        const dropdm = document.querySelector('.dr_menu')
    
        toggle_btn.onclick = function() {
            dropdm.classList.toggle('open')
            const isOpen = dropdm.classList.contains('open')
    
            togglebtnicon.classList = isOpen
            ? "fa-solid fa-xmark"
            : "fa-solid fa-bars"
        
    }