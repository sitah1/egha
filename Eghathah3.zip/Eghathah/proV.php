<?php
	$Volunteer_ID = $_POST['Volunteer_ID'];
	$Volunteer_Name = $_POST['Volunteer_Name'];
	$Volunteer_Num = $_POST['Volunteer_Num'];

	// Database connection
	$conn = new mysqli('localhost','root','','eghatha');
	if($conn->connect_error){
		echo "$conn->connect_error";
		die("Connection Failed : ". $conn->connect_error);
	} else {
		$stmt = $conn->prepare("insert into Volunteer(Volunteer_ID, Volunteer_Name, Volunteer_Num) values(?, ?, ?)");
		$stmt->bind_param("isi", $Volunteer_ID, $Volunteer_Name, $Volunteer_Num);
		$execval= $stmt->execute();
	    echo $execval;
		echo "<script> alert('Registration successfully...') </script>";
		$stmt->close();
		$conn->close();
	}
?>