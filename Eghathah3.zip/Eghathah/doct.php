<?php
  // PHP code to process the form submission and insert data into the database

  // Check if the form is submitted
  if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['doctor_login'])) {
    // Retrieve the form data
    $Doctor_ID = $_POST['Doctor_ID'];
    $Doctor_Name = $_POST['Doctor_Name'];
    $Hospital_Name = $_POST['Hospital_Name'];
    $Doctor_Section = $_POST['Doctor_Section'];
    $Doctor_Num = $_POST['Doctor_Num'];

    // Database connection details
    $db_name = "mysql:host=localhost;dbname=eghatha;charset=utf8";
    $username = "root";
    $password = "";

    try {
      // Create a new PDO instance
      $conn = new PDO($db_name, $username, $password);

      // Set the PDO error mode to exception
      $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

      //Doctor_ID	Hospital_Name	Doctor_Name	Doctor_Section	Doctor_num	
      // Prepare and execute the database query
      $sql = "INSERT INTO `doctor` ( Doctor_ID, Hospital_Name, Doctor_Name, Doctor_Section, Doctor_Num) VALUES (?, ?, ?, ?,?)";

      $stmt = $conn->prepare($sql);
      $stmt->execute([$Doctor_ID, $Hospital_Name, $Doctor_Name, $Doctor_Section, $Doctor_Num]);

      echo "<script>alert('تم تسجيل البيانات بنجاح');</script>";
    } catch (PDOException $e) {
      echo "<script>alert('حدث خطأ أثناء تسجيل البيانات: " . $e->getMessage() . "');</script>";
    } finally {
      // Close the database connection
      $conn = null;
    }
  }
  ?>