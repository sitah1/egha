<?php
	$User_ID = $_POST['User_ID'];
	$User_Email = $_POST['User_Email'];
	$User_Password = $_POST['User_Password'];

	// Database connection
	$conn = new mysqli('localhost','root','','eghatha');
	if($conn->connect_error){
		echo "$conn->connect_error";
		die("Connection Failed : ". $conn->connect_error);
	} else {
		$stmt = $conn->prepare("insert into user(User_ID, User_Email, User_Password) values(?, ?, ?)");
		$stmt->bind_param("isi", $User_ID, $User_Email, $User_Password);
		$execval= $stmt->execute();
	    echo $execval;
		echo "<script> alert('Registration successfully...') </script>";
		$stmt->close();
		$conn->close();
	}
?>