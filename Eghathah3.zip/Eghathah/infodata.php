<?php

  $dbServername = "localhost";
  $dbUsername = "root";
  $dbPassword ="";
  $dbName = "eghatha";
  
  $conn = mysqli_connect($dbServername, $dbUsername, $dbPassword, $dbName);
  
?>

<!DOCTYPE html>
<html>
    <head>
        <title> info </title>
</head>
<body>
    
    <?php
    $conn = new mysqli('localhost','root','','eghatha');
    $sql = "SELECT * FROM  patient;";
    $result = mysqli_query($conn, $sql);
    
    $array = array();

    while($row =mysqli_fetch_assoc($result))
    {
        $array[] = $row;
    }

    echo '<pre>';
    print_r($array);
    echo '<pre>';
    
    ?>

</body>
</html>

