<?php
 require_once('dbh.php');


	$patientID = $_POST['Patient_ID'];
	$name = $_POST['Patient_Name'];
	$age = $_POST['Patient_Age'];
	$weight = $_POST['Patient_Weight'];
	$height = $_POST['Patient_Height'];
	$bloodG = $_POST['Patient_BloodG'];
	$medicine = $_POST['Patient_Medicine'];
	$firstAid = $_POST['Patient_FirstAid'];
	$medicalHistory = $_POST['Patient_MedicalHistory'];
	$emergencyNum = $_POST['Relatives_EmergencyNum'];

 
		 
	$stmt = $conn->prepare("INSERT INTO patient (Patient_ID, Patient_Name, Patient_Age, Patient_Weight, Patient_Height, Patient_BloodG, Patient_Medicine, Patient_FirstAid, Patient_MedicalHistory, Relatives_EmergencyNum) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
	$stmt->bind_param("isiiissssi", $patientID, $name, $age, $weight, $height, $bloodG, $medicine, $firstAid, $medicalHistory, $emergencyNum);
	$execval = $stmt->execute();
	if ($execval) {
		$newPatientID = $stmt->insert_id;
		echo "<script>alert('Registration successful. Patient ID: $newPatientID');</script>";
	} else {
		echo "<script>alert('Failed to create account');</script>";
	}
	$stmt->close();
	$conn->close();
?>

<!DOCTYPE html>
<html>
<head>
    <title>QR Code Generator</title>
    <script src="https://rawgit.com/davidshimjs/qrcodejs/gh-pages/qrcode.min.js"></script>
</head>
<body>
    <h1>QR Code Generator</h1>
    <div id="qrcode"></div>

    <?php
 		$url = "display_info.php?patient_id=" . $newPatientID; 
        echo "<script>";
        echo "var qrcode = new QRCode(document.getElementById('qrcode'), {width: 200,height: 200});";
        echo "qrcode.makeCode('$url');";
        echo "</script>";
    ?>
</body>
</html>
