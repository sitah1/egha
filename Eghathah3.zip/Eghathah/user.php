<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {

  if (isset($_POST["login"])) {
      $username = $_POST["name"];
      $password = $_POST["password"];
      $query = "SELECT * FROM user WHERE name ='$username' AND passwrod= '$password'";
      $result = $conn->query($query);
      if ($result->num_rows > 0) {
          echo "Login successful!";
      } else {
          echo "Login failed. Please check your username and password.";
      }
  }
} 
if ($_SERVER["REQUEST_METHOD"] == "POST") {
  if (isset($_POST["register"])) {
    $User_Name = $_POST["User_Name"];
    $User_ID = $_POST["User_ID"];
    $User_Email = $_POST["User_Email"];
    $User_Password = $_POST["User_Password "];
    $confirmPassword = $_POST["confirmPassword"];
  
    if ($User_Password  !== $confirmPassword) {
        echo "كلمة المرور غير متطابقين.";
    } else {
        $query = "INSERT INTO usert (User_Name, User_ID, User_Email, User_Passwrod) VALUES ('$User_Name', '$User_Name', '$User_Email', '$User_password')";
        $result = $conn->query($query);
  
        if ($result) {
            echo "تم التسجيل بنجاح!";
        } else {
            echo "فشل في التسجيل. يرجى المحاولة مرة أخرى.";
        }
    }
  }
 $conn->close();
}

?>
